import * as ts from "typescript";
export declare function createLanguageServiceHost(fileName: string, source: string): ts.LanguageServiceHost;
export declare function createLanguageService(fileName: string, source: string): ts.LanguageService;
