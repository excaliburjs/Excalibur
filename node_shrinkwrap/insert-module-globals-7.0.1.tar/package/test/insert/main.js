t.equal(__filename, '/main.js');
t.equal(__dirname, '/');

require('./foo');
