t.equal(eval('cust' + 'om'), eval('expected'));
