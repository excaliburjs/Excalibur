var _ = require('./lodash').noConflict().runInContext();
module.exports = require('./fp/convert')(_);
