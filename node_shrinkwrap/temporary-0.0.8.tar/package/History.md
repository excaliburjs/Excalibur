
0.0.8 / 2014-01-05
==================

  * Fix Node 0.11 error when path is frozen.

0.0.7 / 2013-09-25
==================

  * Normalize windows paths correctly
  * On Windows lib/detector.js not adding trailing slash when needed.

0.0.6 / 2013-09-13
==================

  * Export Dir and File in index
  * Test on Node 0.10 as well
  * Get tests passing on OSX
  * Update Readme.md

0.0.5 / 2012-11-12
==================

  * Solved process.env issue in detector on certain version so linux.
