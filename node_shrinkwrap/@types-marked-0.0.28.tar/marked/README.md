# Installation
> `npm install --save @types/marked`

# Summary
This package contains type definitions for Marked (https://github.com/chjj/marked).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/marked

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:59 GMT
 * File structure: Mixed
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: marked

# Credits
These definitions were written by William Orr <https://github.com/worr>.
