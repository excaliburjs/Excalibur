Code based on https://github.com/dominictarr/json-buffer but adapted to be simpler to run in a purely node.js environment
