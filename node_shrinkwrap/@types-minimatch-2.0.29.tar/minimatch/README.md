# Installation
> `npm install --save @types/minimatch`

# Summary
This package contains type definitions for Minimatch 2.0.8 (https://github.com/isaacs/minimatch).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/minimatch

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:59 GMT
 * File structure: ProperModule
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: M

# Credits
These definitions were written by vvakame <https://github.com/vvakame/>.
