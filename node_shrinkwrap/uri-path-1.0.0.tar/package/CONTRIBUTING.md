See [Ult Foundation Contributor's Guide](https://github.com/UltFoundation/Ultiomatic.js/blob/master/CONTRIBUTING.md).
