file-sync-cmp
=============

[![Build Status](https://travis-ci.org/mgeisler/file-sync-cmp.svg?branch=master)](https://travis-ci.org/mgeisler/file-sync-cmp)

Synchronous file comparison for Node.js.


Release History
---------------

* 0.1.1 (2015-02-22): Close file descriptors after comparison.

* 0.1.0 (2014-12-14): First public release.
