# grunt-legacy-log-utils
> Static methods for the Grunt 0.4.x logger.

[![Build Status: Linux](https://travis-ci.org/gruntjs/grunt-legacy-log-utils.svg?branch=master)](https://travis-ci.org/gruntjs/grunt-legacy-log-utils)
[![Build Status: Windows](https://ci.appveyor.com/api/projects/status/a6s4cy3fcbl33hnp?svg=true)](https://ci.appveyor.com/project/gruntjs/grunt-legacy-log-utils)
[![Built with Grunt](https://cdn.gruntjs.com/builtwith.png)](http://gruntjs.com/)
