var é = require('./bar');

module.exports = function (ñ) {
    return ñ * 111 + é(n);
};
