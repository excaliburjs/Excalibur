module.exports = function (ñ) {
    return ñ * 100;
};
