var f = require('./f.js');

t.equal(f(14), 11, 'transformation scope');
