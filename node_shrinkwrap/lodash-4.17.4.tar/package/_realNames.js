/** Used to lookup unminified function names. */
var realNames = {};

module.exports = realNames;
