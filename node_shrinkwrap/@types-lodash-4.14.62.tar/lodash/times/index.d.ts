import { times } from "../index";
export = times;
