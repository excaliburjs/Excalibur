# Installation
> `npm install --save @types/lodash`

# Summary
This package contains type definitions for Lo-Dash (http://lodash.com/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lodash

Additional Details
 * Last updated: Fri, 07 Apr 2017 22:26:35 GMT
 * Dependencies: none
 * Global values: _

# Credits
These definitions were written by Brian Zengel <https://github.com/bczengel>, Ilya Mochalov <https://github.com/chrootsu>, Stepan Mikhaylyuk <https://github.com/stepancar>, Eric L Anderson <https://github.com/ericanderson>.
