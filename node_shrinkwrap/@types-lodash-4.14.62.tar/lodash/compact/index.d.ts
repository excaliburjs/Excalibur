import { compact } from "../index";
export = compact;
