import { findLastIndex } from "../index";
export = findLastIndex;
