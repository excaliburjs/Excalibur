import { inRange } from "../index";
export = inRange;
