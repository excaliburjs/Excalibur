import { split } from "../index";
export = split;
