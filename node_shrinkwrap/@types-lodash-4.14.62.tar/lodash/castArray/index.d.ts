import { castArray } from "../index";
export = castArray;
