import { endsWith } from "../index";
export = endsWith;
