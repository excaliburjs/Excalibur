import * as _ from "../index";
export = _;
