import { initial } from "../index";
export = initial;
