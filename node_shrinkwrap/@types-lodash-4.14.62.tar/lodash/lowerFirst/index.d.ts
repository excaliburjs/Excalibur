import { lowerFirst } from "../index";
export = lowerFirst;
