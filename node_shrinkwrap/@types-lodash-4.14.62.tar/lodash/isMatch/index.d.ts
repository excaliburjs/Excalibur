import { isMatch } from "../index";
export = isMatch;
