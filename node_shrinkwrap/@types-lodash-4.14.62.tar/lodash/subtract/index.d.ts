import { subtract } from "../index";
export = subtract;
