import { isPlainObject } from "../index";
export = isPlainObject;
