import { unset } from "../index";
export = unset;
