import { runInContext } from "../index";
export = runInContext;
