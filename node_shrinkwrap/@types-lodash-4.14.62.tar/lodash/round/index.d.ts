import { round } from "../index";
export = round;
