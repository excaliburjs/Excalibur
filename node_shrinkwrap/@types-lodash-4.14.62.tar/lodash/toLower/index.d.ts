import { toLower } from "../index";
export = toLower;
