import { padStart } from "../index";
export = padStart;
