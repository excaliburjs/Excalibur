import { unary } from "../index";
export = unary;
