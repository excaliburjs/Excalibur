import { toPairsIn } from "../index";
export = toPairsIn;
