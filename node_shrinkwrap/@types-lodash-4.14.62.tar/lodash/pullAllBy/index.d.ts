import { pullAllBy } from "../index";
export = pullAllBy;
