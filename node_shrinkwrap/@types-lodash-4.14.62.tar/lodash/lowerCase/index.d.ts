import { lowerCase } from "../index";
export = lowerCase;
