/* eslint-disable */
Generator = {
	getRandomNumber: function () {
		return 4;
	}
};
