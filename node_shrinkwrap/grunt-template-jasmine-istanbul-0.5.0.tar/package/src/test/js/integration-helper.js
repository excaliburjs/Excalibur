/* eslint-disable */
__coverage__ = {
	'integration-helper': {
		path: './src/test/js/integration-helper.js',
		s: {},
		b: {},
		f: {},
		branchMap: {},
		fnMap: {},
		statementMap: {}
	}
};
