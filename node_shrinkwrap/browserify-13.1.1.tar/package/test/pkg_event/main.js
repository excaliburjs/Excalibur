console.log(require('aaa'))
