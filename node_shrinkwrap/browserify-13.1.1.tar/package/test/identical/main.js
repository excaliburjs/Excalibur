var x = require('./x');
var y = require('./y');
console.log(x());
console.log(x());
console.log(y());
console.log(y());
