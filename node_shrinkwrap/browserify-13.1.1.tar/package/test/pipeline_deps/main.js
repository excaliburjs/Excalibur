var foo = require('./foo');
console.log('main: ' + foo(5));
