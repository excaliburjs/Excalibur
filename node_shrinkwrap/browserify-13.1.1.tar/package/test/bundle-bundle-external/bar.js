module.exports = 'bar';
done();
