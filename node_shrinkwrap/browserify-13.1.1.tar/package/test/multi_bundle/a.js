var b = require('./b');
t.equal(b, 'foo');
module.exports = 'bar';
