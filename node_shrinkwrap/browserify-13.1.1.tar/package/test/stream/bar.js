module.exports = require('./foo.js') * 4 / 3
