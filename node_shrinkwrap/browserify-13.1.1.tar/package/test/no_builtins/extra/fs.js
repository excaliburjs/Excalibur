exports.readFileSync = function () { return 'WHATEVER' };
