t.equal(XXX * 5, 555);
