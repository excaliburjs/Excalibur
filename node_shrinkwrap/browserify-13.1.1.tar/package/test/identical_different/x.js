var op = require('op');
var i = 0;
module.exports = function () { i = op(i); return i };
