console.log(require('aaa/what.js'))
