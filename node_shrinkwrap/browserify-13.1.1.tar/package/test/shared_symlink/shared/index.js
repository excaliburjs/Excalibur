module.exports = require('foo') * 2
