(function () {
    var x = 5;
    var x = 6;
    console.log('ogre')
})();
