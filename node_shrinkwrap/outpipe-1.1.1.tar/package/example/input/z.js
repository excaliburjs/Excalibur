if (false) console.log('welcome!')
console.log('keep out')
