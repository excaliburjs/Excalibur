for (var i = 0; i < 100; i++) {
    var n = 500;
    console.log('i=', i);
}
