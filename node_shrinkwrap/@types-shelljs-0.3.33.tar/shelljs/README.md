# Installation
> `npm install --save @types/shelljs`

# Summary
This package contains type definitions for ShellJS v0.3.0 (http://shelljs.org).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/shelljs

Additional Details
 * Last updated: Tue, 22 Nov 2016 20:59:30 GMT
 * File structure: ProperModule
 * Library Dependencies: node
 * Module Dependencies: child_process
 * Global values: none

# Credits
These definitions were written by Niklas Mollenhauer <https://github.com/nikeee>.
