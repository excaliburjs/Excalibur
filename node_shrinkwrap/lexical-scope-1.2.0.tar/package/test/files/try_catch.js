function foo() {
  try {

  } catch (ex) {
    foo(ex)
  }
}