console.log(Buffer('abc'))
