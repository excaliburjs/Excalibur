var foo;
foo = bar;
