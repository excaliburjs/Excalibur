* Michele Bini (original Curve25519 core code: curve25519.js)
* Ron Garret (original Ed25519 code: fast-djbec.js)
* Guy Kloss (package refactoring, unit testing)
