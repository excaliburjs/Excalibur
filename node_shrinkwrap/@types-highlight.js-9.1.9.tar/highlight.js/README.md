# Installation
> `npm install --save @types/highlight.js`

# Summary
This package contains type definitions for highlight.js (https://github.com/isagalaev/highlight.js).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/highlight.js

Additional Details
 * Last updated: Wed, 28 Dec 2016 04:05:49 GMT
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: hljs

# Credits
These definitions were written by Niklas Mollenhauer <https://github.com/nikeee/>, Jeremy Hull <https://github.com/sourrust>.
