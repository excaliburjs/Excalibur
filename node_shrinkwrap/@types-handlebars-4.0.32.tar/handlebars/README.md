# Installation
> `npm install --save @types/handlebars`

# Summary
This package contains type definitions for Handlebars (http://handlebarsjs.com/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/handlebars

Additional Details
 * Last updated: Fri, 10 Mar 2017 07:28:34 GMT
 * Dependencies: none
 * Global values: Handlebars, hbs

# Credits
These definitions were written by Boris Yankov <https://github.com/borisyankov/>.
