import moment from '../moment';

export default moment.defineLocale('bg-x', {
    parentLocale: 'bg'
});
