// test to check that extended ascii will be managed correctly :
(function(µ){
	var µlogged = µ('.jHeaderConnected');
	var ಠ_ಠ = 42;
}(jQuery));
