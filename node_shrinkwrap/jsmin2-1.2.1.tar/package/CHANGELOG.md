# node-jsmin2 changelog
1.2.1 - Repaired EOF detection via @tlbtlbtlb in #7

1.2.0 - Repaired characters with code over 126 via @vooor in #5

1.1.9 - Added Travis CI

1.1.8 - Added foundry for release

Before 1.1.8 - See `git log`
