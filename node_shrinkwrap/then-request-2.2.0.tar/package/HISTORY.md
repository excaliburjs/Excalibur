2.1.1 / 2015-02-12
==================

 * Preserve header casing

2.1.0 / 2015-01-21
==================

 * Add retry, maxRedirects and timeout

2.0.3 / 2015-01-21
==================

 * Add a "dist" folder with prebuilt clients for browsers

2.0.1 / 2015-01-14
==================

 * Add support for 303 See Other redirects

1.1.0 / 2014-12-18
==================

 * Support not following redirects

1.0.5 / 2014-12-18
==================

 * Update dependencies

1.0.4 / 2014-09-29
==================

 * Update promise to 6.0.0 ([@ForbesLindesay](https://github.com/ForbesLindesay))

1.0.3 / 2014-09-09
==================

 * Update qs to 2.2.3 ([@ForbesLindesay](https://github.com/ForbesLindesay))

1.0.2 / 2014-09-09
==================

 * Add content-length header ([@ForbesLindesay](https://github.com/ForbesLindesay))

1.0.1 / 2014-08-07
==================

 * Update dependencies ([@ForbesLindesay](https://github.com/ForbesLindesay))

1.0.0 / 2014-08-01
==================

 * Completely new API ([@ForbesLindesay](https://github.com/ForbesLindesay))
 * Gzip support ([@ForbesLindesay](https://github.com/ForbesLindesay))
 * Caching support ([@ForbesLindesay](https://github.com/ForbesLindesay))
 * Redirects support ([@ForbesLindesay](https://github.com/ForbesLindesay))
 * Documentation ([@ForbesLindesay](https://github.com/ForbesLindesay))

0.0.4 / 2014-04-02
==================

 * Fix for empty responses ([@ForbesLindesay](https://github.com/ForbesLindesay))

0.0.3 / 2014-04-02
==================

 * Fix for empty responses ([@ForbesLindesay](https://github.com/ForbesLindesay))

0.0.2 / 2014-04-01
==================

 * Fix dependencies ([@Volox](https://github.com/Volox))
 * Update readme ([@Volox](https://github.com/Volox))

0.0.1 / 2014-02-10
==================

 * Initial release ([@ForbesLindesay](https://github.com/ForbesLindesay))
