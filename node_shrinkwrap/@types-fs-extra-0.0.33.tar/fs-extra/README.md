# Installation
> `npm install --save @types/fs-extra`

# Summary
This package contains type definitions for fs-extra (https://github.com/jprichardson/node-fs-extra).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/fs-extra

Additional Details
 * Last updated: Wed, 05 Oct 2016 20:53:32 GMT
 * File structure: ProperModule
 * Library Dependencies: node
 * Module Dependencies: fs, stream
 * Global values: none

# Credits
These definitions were written by midknight41 <https://github.com/midknight41>.
