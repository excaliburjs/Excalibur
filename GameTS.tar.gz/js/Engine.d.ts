/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
module Algebra {
    class Util {
        static Equals(x: number, y: number, delta: number): bool;
    }
    class Point {
        public x: number;
        public y: number;
        constructor(x: number, y: number);
        public minus(p: Point): Vector;
        public plus(v: Vector): Point;
    }
    class Vector {
        public x: number;
        public y: number;
        constructor(x: number, y: number);
        public dot(v: Vector): number;
        public cross(v: Vector): number;
    }
}
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
module Drawing {
    interface IDrawable {
        setScale(scale: number);
        setRotation(radians: number);
        draw(ctx: CanvasRenderingContext2D, x: number, y: number);
    }
    class SpriteSheet {
        public path: string;
        public sprites: any;
        public internalImage: HTMLImageElement;
        constructor(path: string, columns: number, rows: number, spWidth: number, spHeight: number);
        public getAnimationForRow(rowIndex: number, start: number, count: number, speed: number): Animation;
    }
    class Sprite implements IDrawable {
        public sx: number;
        public sy: number;
        public swidth: number;
        public sheight: number;
        public internalImage: HTMLImageElement;
        public scale: number;
        public rotation: number;
        constructor(image: HTMLImageElement, sx: number, sy: number, swidth: number, sheight: number);
        public setRotation(radians: number): void;
        public setScale(scale: number): void;
        public draw(ctx: CanvasRenderingContext2D, x: number, y: number): void;
    }
    class Animation implements IDrawable {
        public sprites: Sprite[];
        public speed: number;
        public maxIndex: number;
        public currIndex: number;
        public oldTime: number;
        public rotation: number;
        public scale: number;
        constructor(images: Sprite[], speed: number);
        public setRotation(radians: number): void;
        public setScale(scale: number): void;
        public tick(): void;
        public draw(ctx: CanvasRenderingContext2D, x: number, y: number): void;
    }
}
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
module Common {
    interface ICamera {
        applyTransform(cts: CanvasRenderingContext2D, delta: number): void;
    }
    interface IEngine {
        getKeys();
        getKeyMap(): {
            [key: string]: number;
        };
        update(engine: IEngine, delta: number);
        draw(ctx: CanvasRenderingContext2D, delta: number);
    }
    interface IPhysicsSystem {
        update(delta: number);
        addActor(actor: IActor): void;
        removeActor(actor: IActor): void;
        getProperty(key: string): any;
        setProperty(key: string, value: any): void;
    }
    interface IActor {
        getX(): number;
        setX(x: number);
        getY(): number;
        setY(y: number);
        getDx(): number;
        setDx(dx: number);
        getDy(): number;
        setDy(dy: number);
        getAx(): number;
        setAx(ax: number);
        getAy(): number;
        setAy(ay: number);
        setPhysicsSystem(IPhysicsSystem);
        update(engine: IEngine, delta: number);
        draw(ctx: CanvasRenderingContext2D, delta: number);
    }
}
module Camera {
    class SideCamera implements Common.ICamera {
        public follow: Common.IActor;
        constructor();
        public setActorToFollow(actor: Common.IActor): void;
        public applyTransform(ctx: CanvasRenderingContext2D, delta: number): void;
    }
}
module Core {
    class Sound {
        public path: string;
        public sound: HTMLAudioElement;
        constructor(path: string);
        public play(): void;
    }
    class Actor implements Common.IActor {
        public physicsSystem: Common.IPhysicsSystem;
        public x: number;
        public y: number;
        public dx: number;
        public dy: number;
        public ax: number;
        public ay: number;
        constructor();
        public animations: {
            [key: string]: Drawing.Animation;
        };
        public currentAnimation: Drawing.Animation;
        public addAnimation(key: string, animation: Drawing.Animation): void;
        public setPhysicsSystem(system: Common.IPhysicsSystem): void;
        public setX(x: number): void;
        public getX(): number;
        public setY(y: number): void;
        public getY(): number;
        public setDx(dx: number): void;
        public getDx(): number;
        public setDy(dy: number): void;
        public getDy(): number;
        public setAx(ax: number): void;
        public getAx(): number;
        public setAy(ay: number): void;
        public getAy(): number;
        public playAnimation(key): void;
        public update(engine: Common.IEngine, delta: number): void;
        public draw(ctx: CanvasRenderingContext2D, delta: number): void;
    }
    class Color {
        public r: number;
        public g: number;
        public b: number;
        constructor(r: number, g: number, b: number);
        public toString(): string;
    }
    class SideScrollerPhysics implements Common.IPhysicsSystem {
        public actor: Player;
        public engine: SimpleGame;
        private gravity;
        private onGround;
        private actors;
        constructor(actor: Player, engine: SimpleGame);
        public addActor(actor: Common.IActor): void;
        public removeActor(actor: Common.IActor): void;
        public getProperty(key: string): any;
        public setProperty(key: string, value: any): void;
        public setGravity(gravity: number): void;
        public update(delta: number): void;
    }
    class SideScrollerInertiaPhysics implements Common.IPhysicsSystem {
        private actors;
        constructor();
        public addActor(actor: Common.IActor): void;
        public removeActor(actor: Common.IActor): void;
        public getProperty(key: string): any;
        public setProperty(key: string, value: any): void;
        public update(delta: number): void;
    }
    class TopDownPhysics implements Common.IPhysicsSystem {
        public engine: SimpleGame;
        private friction;
        private actors;
        constructor(engine: SimpleGame);
        public addActor(actor: Common.IActor): void;
        public removeActor(actor: Common.IActor): void;
        public setFriction(friction: number): void;
        public getProperty(key: string): any;
        public setProperty(key: string, value: any): void;
        public update(delta: number): void;
    }
    class Player extends Actor {
        public x: number;
        public y: number;
        public width: number;
        public height: number;
        private box;
        public handlers: {
            [key: string]: (player: Player) => void;
        };
        constructor(x: number, y: number, width: number, height: number);
        public setX(x: number): void;
        public adjustX(x: number): void;
        public getX(): number;
        public setY(y: number): void;
        public adjustY(y: number): void;
        public getY(): number;
        public getBox(): Box;
        public setPhysicsSystem(system: Common.IPhysicsSystem): void;
        public getPhysicsSystem(): Common.IPhysicsSystem;
        public addKeyHandler(key: string[], handler: (player: Player) => void): void;
        public update(engine: Common.IEngine, delta: number): void;
        public draw(ctx: CanvasRenderingContext2D, delta: number): void;
    }
    class Block extends Actor {
        public x: number;
        public y: number;
        public width: number;
        public height: number;
        private color;
        private boundingBox;
        constructor(x: number, y: number, width: number, height: number, color: Color);
        public getBox(): Box;
        public toString(): string;
        public update(engine: Common.IEngine, delta: number): void;
        public draw(ctx: CanvasRenderingContext2D, delta: number): void;
    }
    class Overlap {
        public x: number;
        public y: number;
        constructor(x: number, y: number);
    }
    class Box {
        public x: number;
        public y: number;
        public width: number;
        public height: number;
        constructor(x: number, y: number, width: number, height: number);
        public getLeft(): number;
        public setLeft(left: number): void;
        public getRight(): number;
        public setRight(right: number): void;
        public getTop(): number;
        public setTop(top: number): void;
        public getBottom(): number;
        public setBottom(bottom: number): void;
        public getOverlap(box: Box): Overlap;
        public collides(box: Box): bool;
    }
    class SimpleGame implements Common.IEngine {
        public width: number;
        public height: number;
        public fullscreen: bool;
        public backgroundColor: Color;
        public debugFontSize: number;
        public actors: Common.IActor[];
        public level: Block[];
        private physicsSystem;
        private keys;
        private keyMap;
        public canv: HTMLCanvasElement;
        public ctx: CanvasRenderingContext2D;
        public camera: Common.ICamera;
        constructor(width: number, height: number, fullscreen?: bool, backgroundColor?: Color);
        public getKeys(): any[];
        public getKeyMap(): {
            [key: string]: number;
        };
        public update(engine: Common.IEngine, delta: number): void;
        public addPhysics(physicsSystem: Common.IPhysicsSystem): void;
        public addCamera(camera: Common.ICamera): void;
        public getCamera(): Common.ICamera;
        public draw(ctx, delta: number): void;
        public addActor(actor: Actor): void;
        public addBlock(block: Block): void;
        public start(): void;
    }
}
