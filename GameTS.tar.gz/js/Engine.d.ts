/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
module Algebra {
    class Util {
        static Equals(x: number, y: number, delta: number): bool;
    }
    class Point {
        public x: number;
        public y: number;
        constructor(x: number, y: number);
        public minus(p: Point): Vector;
        public plus(v: Vector): Point;
    }
    class Vector {
        public x: number;
        public y: number;
        constructor(x: number, y: number);
        public dot(v: Vector): number;
        public cross(v: Vector): number;
    }
}
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
module Drawing {
    interface IDrawable {
        setScale(scale: number);
        setRotation(radians: number);
        draw(ctx: CanvasRenderingContext2D, x: number, y: number);
    }
    class SpriteSheet {
        public path: string;
        public sprites: any;
        public internalImage: HTMLImageElement;
        constructor(path: string, columns: number, rows: number, spWidth: number, spHeight: number);
        public getAnimationForRow(rowIndex: number, start: number, count: number, speed: number): Animation;
    }
    class Sprite implements IDrawable {
        public sx: number;
        public sy: number;
        public swidth: number;
        public sheight: number;
        public internalImage: HTMLImageElement;
        public scale: number;
        public rotation: number;
        constructor(image: HTMLImageElement, sx: number, sy: number, swidth: number, sheight: number);
        public setRotation(radians: number): void;
        public setScale(scale: number): void;
        public draw(ctx: CanvasRenderingContext2D, x: number, y: number): void;
    }
    class Animation implements IDrawable {
        public sprites: Sprite[];
        public speed: number;
        public maxIndex: number;
        public currIndex: number;
        public oldTime: number;
        public rotation: number;
        public scale: number;
        constructor(images: Sprite[], speed: number);
        public setRotation(radians: number): void;
        public setScale(scale: number): void;
        public tick(): void;
        public draw(ctx: CanvasRenderingContext2D, x: number, y: number): void;
    }
}
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
module Camera {
    class SideCamera {
        public follow: any;
        constructor();
        public setActorToFollow(actor: any): void;
        public applyTransform(ctx: CanvasRenderingContext2D, delta: number): void;
    }
}
module Core {
    class Sound {
        public path: string;
        public sound: HTMLAudioElement;
        constructor(path: string);
        public play(): void;
    }
    class Actor {
        public dx: number;
        public dy: number;
        public ax: number;
        public ay: number;
        constructor();
        public animations: {
            [key: string]: Drawing.Animation;
        };
        public currentAnimation: Drawing.Animation;
        public addAnimation(key: string, animation: Drawing.Animation): void;
        public playAnimation(key): void;
        public update(engine: SimpleGame, delta: number): void;
        public draw(ctx: CanvasRenderingContext2D, delta: number): void;
    }
    class Color {
        public r: number;
        public g: number;
        public b: number;
        constructor(r: number, g: number, b: number);
        public toString(): string;
    }
    interface IPhysicsSystem {
        update(delta: number);
        isGround(): bool;
        setGround(onGround: bool);
    }
    class SideScrollerPhysics implements IPhysicsSystem {
        public actor: Player;
        public engine: SimpleGame;
        public gravity: number;
        public onGround: bool;
        constructor(actor: Player, engine: SimpleGame);
        public isGround(): bool;
        public setGround(onGround: bool): void;
        public setGravity(gravity: number): void;
        public update(delta: number): void;
    }
    class SideScrollerInertiaPhysics implements IPhysicsSystem {
        constructor();
        public isGround(): bool;
        public setGround(onGround: bool): void;
        public update(delta: number): void;
    }
    class TopDownPhysics implements IPhysicsSystem {
        public actor: Player;
        public engine: SimpleGame;
        public friction: number;
        constructor(actor: Player, engine: SimpleGame);
        public setFriction(friction: number): void;
        public isGround(): bool;
        public setGround(onGround: bool): void;
        public update(delta: number): void;
    }
    class Player extends Actor {
        public x: number;
        public y: number;
        public width: number;
        public height: number;
        public box: Box;
        public system: IPhysicsSystem;
        public handlers: {
            [key: string]: (player: Player) => void;
        };
        constructor(x: number, y: number, width: number, height: number);
        public setPhysicsSystem(system: IPhysicsSystem): void;
        public getPhysicsSystem(): IPhysicsSystem;
        public addKeyHandler(key: string[], handler: (player: Player) => void): void;
        public update(engine: SimpleGame, delta: number): void;
        public draw(ctx: CanvasRenderingContext2D, delta: number): void;
    }
    class Block extends Actor {
        public x: number;
        public y: number;
        public width: number;
        public height: number;
        public color: Color;
        public boundingBox: Box;
        constructor(x: number, y: number, width: number, height: number, color: Color);
        public toString(): string;
        public update(engine: SimpleGame, delta: number): void;
        public draw(ctx: CanvasRenderingContext2D, delta: number): void;
    }
    class Overlap {
        public x: number;
        public y: number;
        constructor(x: number, y: number);
    }
    class Box {
        public x: number;
        public y: number;
        public width: number;
        public height: number;
        constructor(x: number, y: number, width: number, height: number);
        public getLeft(): number;
        public setLeft(left: number): void;
        public getRight(): number;
        public setRight(right: number): void;
        public getTop(): number;
        public setTop(top: number): void;
        public getBottom(): number;
        public setBottom(bottom: number): void;
        public getOverlap(box: Box): Overlap;
        public collides(box: Box): bool;
    }
    class Game {
        constructor();
    }
    class TopDownGame extends Game {
        constructor();
    }
    class SimpleGame extends Game {
        public width: number;
        public height: number;
        public fullscreen: bool;
        public backgroundColor: Color;
        public debugFontSize: number;
        public actors: Actor[];
        public level: Block[];
        public keys: any[];
        public keyMap: {
            [key: string]: number;
        };
        public canv: HTMLCanvasElement;
        public ctx: CanvasRenderingContext2D;
        public camera: Camera.SideCamera;
        constructor(width: number, height: number, fullscreen?: bool, backgroundColor?: Color);
        public update(engine: SimpleGame, delta: number): void;
        public addCamera(camera: Camera.SideCamera): void;
        public draw(ctx, delta: number): void;
        public addActor(actor: Actor): void;
        public addBlock(block: Block): void;
        public start(): void;
    }
}
