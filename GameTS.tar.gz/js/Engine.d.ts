/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
declare module Algebra {
    class Util {
        static Equals(x: number, y: number, delta: number): boolean;
    }
    class Point {
        public x: number;
        public y: number;
        constructor(x: number, y: number);
        public minus(p: Point): Vector;
        public plus(v: Vector): Point;
    }
    class Vector {
        public x: number;
        public y: number;
        constructor(x: number, y: number);
        public dot(v: Vector): number;
        public cross(v: Vector): number;
    }
}
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
declare module Drawing {
    interface IDrawable {
        setScale(scale: number);
        setRotation(radians: number);
        draw(ctx: CanvasRenderingContext2D, x: number, y: number);
    }
    class SpriteSheet {
        public path: string;
        private sprites;
        private internalImage;
        constructor(path: string, columns: number, rows: number, spWidth: number, spHeight: number);
        public getAnimationForRow(rowIndex: number, start: number, count: number, speed: number): Animation;
    }
    class Sprite implements IDrawable {
        public sx: number;
        public sy: number;
        public swidth: number;
        public sheight: number;
        private internalImage;
        private scale;
        private rotation;
        constructor(image: HTMLImageElement, sx: number, sy: number, swidth: number, sheight: number);
        public setRotation(radians: number): void;
        public setScale(scale: number): void;
        public draw(ctx: CanvasRenderingContext2D, x: number, y: number): void;
    }
    class Animation implements IDrawable {
        private sprites;
        private speed;
        private maxIndex;
        private currIndex;
        private oldTime;
        private rotation;
        private scale;
        constructor(images: Sprite[], speed: number);
        public setRotation(radians: number): void;
        public setScale(scale: number): void;
        public tick(): void;
        public draw(ctx: CanvasRenderingContext2D, x: number, y: number): void;
    }
}
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
declare module Common {
    interface IEngine {
        getKeys();
        getKeyMap(): {
            [key: string]: number;
        };
        getActors(): IActor[];
        getLevel(): IActor[];
        getGraphicsCtx(): CanvasRenderingContext2D;
        getCanvas(): HTMLCanvasElement;
        update(engine: IEngine, delta: number);
        draw(ctx: CanvasRenderingContext2D, delta: number);
    }
    interface ICamera {
        applyTransform(engine: IEngine, delta: number): void;
    }
    interface IPhysicsSystem {
        update(delta: number);
        addActor(actor: IActor): void;
        removeActor(actor: IActor): void;
        getProperty(key: string): any;
        setProperty(key: string, value: any): void;
    }
    interface IColor {
        r: number;
        g: number;
        b: number;
        a: number;
        toString(): string;
    }
    interface ISoundClip {
    }
    interface IOverlap {
        x: number;
        y: number;
    }
    interface ICollidable {
        collides(primitive: ICollidable): boolean;
        collidesWithBox(box: IBoundingBox): boolean;
        collidesWithCircle(circle: IBoundingCircle): boolean;
        collidesWithPoly(poly: IBoundingPoly): boolean;
        collidesWithPixels(pixels: IBoundingPixels): boolean;
        getOverlapWithBox(box: IBoundingBox): IOverlap;
        getOverlapWithCircle(circle: IBoundingCircle): IOverlap;
        getOverlapWithPoly(poly: IBoundingPoly): IOverlap;
        getOverlapWithPixels(pixels: IBoundingPixels): IOverlap;
    }
    interface IBoundingBox extends ICollidable {
    }
    interface IBoundingCircle extends ICollidable {
    }
    interface IBoundingPoly extends ICollidable {
    }
    interface IBoundingPixels extends ICollidable {
    }
    interface IBox {
        getLeft(): number;
        setLeft(left: number);
        getRight(): number;
        setRight(right: number);
        getTop(): number;
        setTop(top: number);
        getBottom(): number;
        setBottom(bottom: number);
        getOverlap(box: IBox): IOverlap;
        collides(box: IBox): boolean;
    }
    interface IActor {
        getX(): number;
        setX(x: number);
        getY(): number;
        setY(y: number);
        getDx(): number;
        setDx(dx: number);
        getDy(): number;
        setDy(dy: number);
        getAx(): number;
        setAx(ax: number);
        getAy(): number;
        setAy(ay: number);
        adjustX(x: number);
        adjustY(y: number);
        setPhysicsSystem(IPhysicsSystem);
        getPhysicsSystem(): IPhysicsSystem;
        setBox(box: IBox);
        getBox(): IBox;
        setColor(color: IColor);
        getColor(): IColor;
        update(engine: IEngine, delta: number);
        draw(ctx: CanvasRenderingContext2D, delta: number);
    }
}
declare module Camera {
    class SideCamera implements Common.ICamera {
        public follow: Common.IActor;
        constructor();
        public setActorToFollow(actor: Common.IActor): void;
        public applyTransform(engine: Common.IEngine, delta: number): void;
    }
    class TopCamera implements Common.ICamera {
        public follow: Common.IActor;
        constructor();
        public setActorToFollow(actor: Common.IActor): void;
        public applyTransform(engine: Common.IEngine, delta: number): void;
    }
}
declare module Physics {
    class Overlap implements Common.IOverlap {
        public x: number;
        public y: number;
        constructor(x: number, y: number);
    }
    class Box implements Common.IBox {
        public x: number;
        public y: number;
        public width: number;
        public height: number;
        constructor(x: number, y: number, width: number, height: number);
        public getLeft(): number;
        public setLeft(left: number): void;
        public getRight(): number;
        public setRight(right: number): void;
        public getTop(): number;
        public setTop(top: number): void;
        public getBottom(): number;
        public setBottom(bottom: number): void;
        public getOverlap(box: Box): Overlap;
        public collides(box: Box): boolean;
    }
    class SideScrollerPhysics implements Common.IPhysicsSystem {
        public actor: Common.IActor;
        public engine: Common.IEngine;
        private gravity;
        private onGround;
        private actors;
        constructor(actor: Common.IActor, engine: Common.IEngine);
        public addActor(actor: Common.IActor): void;
        public removeActor(actor: Common.IActor): void;
        public getProperty(key: string): any;
        public setProperty(key: string, value: any): void;
        public setGravity(gravity: number): void;
        public update(delta: number): void;
    }
    class SideScrollerInertiaPhysics implements Common.IPhysicsSystem {
        private actors;
        constructor();
        public addActor(actor: Common.IActor): void;
        public removeActor(actor: Common.IActor): void;
        public getProperty(key: string): any;
        public setProperty(key: string, value: any): void;
        public update(delta: number): void;
    }
    class TopDownPhysics implements Common.IPhysicsSystem {
        public engine: Common.IEngine;
        private friction;
        private actors;
        constructor(engine: Common.IEngine);
        public addActor(actor: Common.IActor): void;
        public removeActor(actor: Common.IActor): void;
        public setFriction(friction: number): void;
        public getProperty(key: string): any;
        public setProperty(key: string, value: any): void;
        public update(delta: number): void;
    }
}
declare module Sound {
    class SoundClip implements Common.ISoundClip {
        public path: string;
        public sound: HTMLAudioElement;
        constructor(path: string);
        public play(): void;
    }
}
declare module Core {
    var Keys: {
        [key: string]: number;
    };
    class Color implements Common.IColor {
        public r: number;
        public g: number;
        public b: number;
        public a: number;
        constructor(r: number, g: number, b: number, a?: number);
        public toString(): string;
    }
    class Actor implements Common.IActor {
        public physicsSystem: Common.IPhysicsSystem;
        public color: Color;
        public x: number;
        public y: number;
        public dx: number;
        public dy: number;
        public ax: number;
        public ay: number;
        public box: Physics.Box;
        constructor();
        public animations: {
            [key: string]: Drawing.Animation;
        };
        public currentAnimation: Drawing.Animation;
        public addAnimation(key: any, animation: Drawing.Animation): void;
        public setBox(box: Physics.Box): void;
        public getBox(): Physics.Box;
        public setPhysicsSystem(system: Common.IPhysicsSystem): void;
        public getPhysicsSystem(): Common.IPhysicsSystem;
        public setX(x: number): void;
        public getX(): number;
        public setY(y: number): void;
        public getY(): number;
        public setDx(dx: number): void;
        public getDx(): number;
        public setDy(dy: number): void;
        public getDy(): number;
        public setAx(ax: number): void;
        public getAx(): number;
        public setAy(ay: number): void;
        public getAy(): number;
        public adjustX(x: number): void;
        public adjustY(y: number): void;
        public getColor(): Color;
        public setColor(color: Color): void;
        public playAnimation(key): void;
        public update(engine: Common.IEngine, delta: number): void;
        public draw(ctx: CanvasRenderingContext2D, delta: number): void;
    }
    class Player extends Actor {
        public width: number;
        public height: number;
        public handlers: {
            [key: string]: (player: Player) => void;
        };
        constructor(x: number, y: number, width: number, height: number);
        public getBox(): Physics.Box;
        public addKeyHandler(key: string[], handler: (player: Player) => void): void;
        public update(engine: Common.IEngine, delta: number): void;
        public draw(ctx: CanvasRenderingContext2D, delta: number): void;
    }
    class Block extends Actor {
        public x: number;
        public y: number;
        public width: number;
        public height: number;
        private boundingBox;
        constructor(x: number, y: number, width: number, height: number, color?: Color);
        public getBox(): Physics.Box;
        public toString(): string;
        public update(engine: Common.IEngine, delta: number): void;
        public draw(ctx: CanvasRenderingContext2D, delta: number): void;
    }
    class SimpleGame implements Common.IEngine {
        private width;
        public height: number;
        private fullscreen;
        private backgroundColor;
        public actors: Common.IActor[];
        public level: Block[];
        private physicsSystem;
        private fps;
        private isDebugOn;
        private debugColor;
        private debugFontSize;
        private keys;
        private keyMap;
        private reverseKeyMap;
        public canv: HTMLCanvasElement;
        public ctx: CanvasRenderingContext2D;
        public camera: Common.ICamera;
        constructor(width: number, height: number, fullscreen?: boolean, backgroundColor?: Color);
        public setDebugFontSize(debugFontSize: number): void;
        public setDebug(isDebugOn: boolean): void;
        public setDebugColor(debugColor: Color): void;
        public setFps(fps: number): void;
        public setHeight(height: number): void;
        public getHeight(): number;
        public setWidth(width: number): void;
        public getWidth(): number;
        public setFullscreen(fullscreen): void;
        public isFullscreen(): boolean;
        public setBackgroundColor(color: Color): void;
        public getBackgroundColor(): Color;
        public getKeys(): any[];
        public getKeyMap(): {
            [key: string]: number;
        };
        public getActors(): Common.IActor[];
        public getLevel(): Block[];
        public update(engine: Common.IEngine, delta: number): void;
        public addPhysics(physicsSystem: Common.IPhysicsSystem): void;
        public addCamera(camera: Common.ICamera): void;
        public getCamera(): Common.ICamera;
        public getGraphicsCtx(): CanvasRenderingContext2D;
        public getCanvas(): HTMLCanvasElement;
        public draw(ctx, delta: number): void;
        public addActor(actor: Actor): void;
        public addBlock(block: Block): void;
        public start(): void;
    }
}
