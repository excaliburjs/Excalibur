if (typeof window != 'undefined' && !window.requestAnimationFrame) {
    (window).requestAnimationFrame = (window).webkitRequestAnimationFrame || (window).mozRequestAnimationFrame || function (callback) {
        window.setTimeout(callback, 1000 / 60);
    };
}
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
var Algebra;
(function (Algebra) {
    var Util = (function () {
        function Util() {
        }
        Util.Equals = function (x, y, delta) {
            return (((x - delta) <= y) && (y <= (x + delta)));
        };
        return Util;
    })();
    Algebra.Util = Util;

    var Point = (function () {
        function Point(x, y) {
            this.x = x;
            this.y = y;
        }
        Point.prototype.minus = function (p) {
            return new Vector(this.x - p.x, this.y - p.y);
        };

        Point.prototype.plus = function (v) {
            this.x += v.x;
            this.y += v.y;
            return this;
        };
        return Point;
    })();
    Algebra.Point = Point;

    var Vector = (function () {
        function Vector(x, y) {
            this.x = x;
            this.y = y;
        }
        Vector.prototype.dot = function (v) {
            return this.x * v.x + this.y * v.y;
        };

        // 2d cross product returns a scalar
        Vector.prototype.cross = function (v) {
            return this.x * v.y - this.y * v.x;
        };
        return Vector;
    })();
    Algebra.Vector = Vector;
})(Algebra || (Algebra = {}));
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
var Drawing;
(function (Drawing) {
    var SpriteSheet = (function () {
        function SpriteSheet(path, columns, rows, spWidth, spHeight) {
            this.path = path;
            this.columns = columns;
            this.rows = rows;
            this.sprites = [];
            this.internalImage = new Image();
            this.internalImage.src = path;
            this.sprites = new Array(rows * columns);

            for (var i = 0; i < rows; i++) {
                for (var j = 0; j < columns; j++) {
                    this.sprites[i + j * rows] = new Sprite(this.internalImage, j * spWidth, i * spHeight, spWidth, spHeight);
                }
            }
        }
        SpriteSheet.prototype.getAnimationForRow = function (rowIndex, start, count, speed) {
            var begin = start + rowIndex * this.columns;
            return new Animation(this.sprites.slice(begin, begin + count), speed);
        };

        SpriteSheet.prototype.getAnimationByIndices = function (indices, speed) {
            var images = this.sprites.filter(function (sprite, index) {
                return indices.indexOf(index) > -1;
            });
            return new Animation(images, speed);
        };
        return SpriteSheet;
    })();
    Drawing.SpriteSheet = SpriteSheet;

    var Sprite = (function () {
        function Sprite(image, sx, sy, swidth, sheight) {
            this.sx = sx;
            this.sy = sy;
            this.swidth = swidth;
            this.sheight = sheight;
            this.scale = 1.0;
            this.rotation = 0.0;
            this.internalImage = image;
        }
        Sprite.prototype.setRotation = function (radians) {
            this.rotation = radians;
        };

        Sprite.prototype.setScale = function (scale) {
            this.scale = scale;
        };

        Sprite.prototype.draw = function (ctx, x, y) {
            ctx.drawImage(this.internalImage, this.sx, this.sy, this.swidth, this.sheight, x, y, this.swidth * this.scale, this.sheight * this.scale);
        };
        return Sprite;
    })();
    Drawing.Sprite = Sprite;

    var Animation = (function () {
        function Animation(images, speed) {
            this.currIndex = 0;
            this.oldTime = Date.now();
            this.rotation = 0.0;
            this.scale = 1.0;
            this.sprites = images;
            this.speed = speed;
            this.maxIndex = images.length;
        }
        Animation.prototype.setRotation = function (radians) {
            this.rotation = radians;
            for (var i in this.sprites) {
                this.sprites[i].setRotation(radians);
            }
        };

        Animation.prototype.setScale = function (scale) {
            this.scale = scale;
            for (var i in this.sprites) {
                this.sprites[i].setScale(scale);
            }
        };

        Animation.prototype.tick = function () {
            var time = Date.now();
            if ((time - this.oldTime) / 1000 > this.speed) {
                this.currIndex = (this.currIndex + 1) % this.maxIndex;
                this.oldTime = time;
            }
        };

        Animation.prototype.draw = function (ctx, x, y) {
            this.tick();
            this.sprites[this.currIndex].draw(ctx, x, y);
        };
        return Animation;
    })();
    Drawing.Animation = Animation;
})(Drawing || (Drawing = {}));
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/// <reference path="Common.ts" />
var Camera;
(function (Camera) {
    var SideCamera = (function () {
        function SideCamera() {
        }
        SideCamera.prototype.setActorToFollow = function (actor) {
            this.follow = actor;
        };

        SideCamera.prototype.applyTransform = function (engine, delta) {
            engine.getGraphicsCtx().translate(-this.follow.getX() + engine.getCanvas().width / 2.0, 0);
        };
        return SideCamera;
    })();
    Camera.SideCamera = SideCamera;

    var TopCamera = (function () {
        function TopCamera() {
        }
        TopCamera.prototype.setActorToFollow = function (actor) {
            this.follow = actor;
        };

        TopCamera.prototype.applyTransform = function (engine, delta) {
            engine.getGraphicsCtx().translate(-this.follow.getX() + engine.getCanvas().width / 2.0, 0);
            engine.getGraphicsCtx().translate(0, -this.follow.getY() + engine.getCanvas().height / 2.0);
        };
        return TopCamera;
    })();
    Camera.TopCamera = TopCamera;
})(Camera || (Camera = {}));
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/// <reference path="Common.ts" />
var Physics;
(function (Physics) {
    var Overlap = (function () {
        function Overlap(x, y) {
            this.x = x;
            this.y = y;
        }
        return Overlap;
    })();
    Physics.Overlap = Overlap;

    var Box = (function () {
        function Box(x, y, width, height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
        Box.prototype.getLeft = function () {
            return this.x;
        };

        Box.prototype.setLeft = function (left) {
            this.x = left;
        };

        Box.prototype.getRight = function () {
            return this.x + this.width;
        };

        Box.prototype.setRight = function (right) {
            this.width = right - this.x;
        };

        Box.prototype.getTop = function () {
            return this.y;
        };

        Box.prototype.setTop = function (top) {
            this.y = top;
        };

        Box.prototype.getBottom = function () {
            return this.y + this.height;
        };

        Box.prototype.setBottom = function (bottom) {
            this.height = bottom - this.y;
        };

        Box.prototype.getOverlap = function (box) {
            var xover = 0;
            var yover = 0;
            if (this.collides(box)) {
                if (this.getLeft() < box.getRight()) {
                    xover = box.getRight() - this.getLeft();
                }
                if (box.getLeft() < this.getRight()) {
                    var tmp = box.getLeft() - this.getRight();
                    if (Math.abs(xover) > Math.abs(tmp)) {
                        xover = tmp;
                    }
                }

                if (this.getBottom() > box.getTop()) {
                    yover = box.getTop() - this.getBottom();
                }

                if (box.getBottom() > this.getTop()) {
                    var tmp = box.getBottom() - this.getTop();
                    if (Math.abs(yover) > Math.abs(tmp)) {
                        yover = tmp;
                    }
                }
            }
            return new Overlap(xover, yover);
        };

        Box.prototype.collides = function (box) {
            var w = 0.5 * (this.width + box.width);
            var h = 0.5 * (this.height + box.height);

            var dx = (this.x + this.width / 2.0) - (box.x + box.width / 2.0);
            var dy = (this.y + this.height / 2.0) - (box.y + box.height / 2.0);

            if (Math.abs(dx) < w && Math.abs(dy) < h) {
                return true;
            }
        };
        return Box;
    })();
    Physics.Box = Box;

    // Side scroller physics implementation w/o inertia
    var SideScrollerPhysics = (function () {
        function SideScrollerPhysics(actor, engine) {
            this.actor = actor;
            this.engine = engine;
            this.gravity = 4;
            this.onGround = false;
            this.actors = [];
            actor.setPhysicsSystem(this);
        }
        SideScrollerPhysics.prototype.addActor = function (actor) {
            this.actors.push(actor);
            actor.setPhysicsSystem(this);
        };

        SideScrollerPhysics.prototype.removeActor = function (actor) {
            var index = this.actors.indexOf(actor);
            this.actors.splice(index, 1);
        };

        SideScrollerPhysics.prototype.getProperty = function (key) {
            if (key == "onGround") {
                return this.onGround;
            } else {
                return "invalid property";
            }
        };

        SideScrollerPhysics.prototype.setProperty = function (key, value) {
            if (key == "onGround") {
                this.onGround = value;
            }
        };

        SideScrollerPhysics.prototype.setGravity = function (gravity) {
            this.gravity = gravity;
        };

        SideScrollerPhysics.prototype.update = function (delta) {
            this.actor.setAy(this.gravity);

            this.setProperty("onGround", false);

            // Pseudo-Friction
            this.actor.setDx(0);

            for (var i = 0; i < this.engine.getLevel().length; i++) {
                var levelBox = this.engine.getLevel()[i].getBox();

                if (this.actor.getBox().collides(levelBox)) {
                    var overlap = this.actor.getBox().getOverlap(levelBox);
                    if (Math.abs(overlap.y) < Math.abs(overlap.x)) {
                        this.actor.adjustY(overlap.y);
                        this.actor.setDy(0);

                        /// TODO: This isn't quite right since if we collide on the y we are considered "on the ground"
                        this.setProperty("onGround", true);
                    } else {
                        this.actor.adjustX(overlap.x);
                        this.actor.setDx(0);
                    }
                }
            }
        };
        return SideScrollerPhysics;
    })();
    Physics.SideScrollerPhysics = SideScrollerPhysics;

    // Side scroller physics implementation w inertia
    var SideScrollerInertiaPhysics = (function () {
        function SideScrollerInertiaPhysics() {
            this.actors = [];
        }
        SideScrollerInertiaPhysics.prototype.addActor = function (actor) {
            this.actors.push(actor);
            actor.setPhysicsSystem(this);
        };

        SideScrollerInertiaPhysics.prototype.removeActor = function (actor) {
            var index = this.actors.indexOf(actor);
            this.actors.splice(index, 1);
        };
        SideScrollerInertiaPhysics.prototype.getProperty = function (key) {
            return false;
        };
        SideScrollerInertiaPhysics.prototype.setProperty = function (key, value) {
        };
        SideScrollerInertiaPhysics.prototype.update = function (delta) {
        };
        return SideScrollerInertiaPhysics;
    })();
    Physics.SideScrollerInertiaPhysics = SideScrollerInertiaPhysics;

    // Top down game physics implementation
    var TopDownPhysics = (function () {
        function TopDownPhysics(engine) {
            this.engine = engine;
            this.friction = 0;
            this.actors = [];
        }
        TopDownPhysics.prototype.addActor = function (actor) {
            this.actors.push(actor);
            actor.setPhysicsSystem(this);
        };

        TopDownPhysics.prototype.removeActor = function (actor) {
            var index = this.actors.indexOf(actor);
            this.actors.splice(index, 1);
        };

        TopDownPhysics.prototype.setFriction = function (friction) {
            this.friction = friction;
        };
        TopDownPhysics.prototype.getProperty = function (key) {
            return false;
        };

        TopDownPhysics.prototype.setProperty = function (key, value) {
        };

        TopDownPhysics.prototype.update = function (delta) {
            for (var id in this.actors) {
                var actor = this.actors[id];
                if (actor.getDx() != 0) {
                    if (Math.abs(actor.getDx()) <= this.friction) {
                        actor.setDx(0);
                    } else {
                        actor.setDx(actor.getDx() + (actor.getDx() > 0 ? -1 : 1) * this.friction);
                    }
                }

                if (actor.getDy() != 0) {
                    if (Math.abs(actor.getDy()) <= this.friction) {
                        actor.setDy(0);
                    } else {
                        actor.setDy(actor.getDy() + (actor.getDy() > 0 ? -1 : 1) * this.friction);
                    }
                }

                for (var i = 0; i < this.engine.getLevel().length; i++) {
                    var levelBox = this.engine.getLevel()[i].getBox();

                    if (actor.getBox().collides(levelBox)) {
                        var overlap = actor.getBox().getOverlap(levelBox);
                        if (Math.abs(overlap.y) < Math.abs(overlap.x)) {
                            actor.adjustY(overlap.y);
                            actor.setDy(0);
                        } else {
                            actor.adjustX(overlap.x);
                            actor.setDy(0);
                        }
                    }
                }
            }
        };
        return TopDownPhysics;
    })();
    Physics.TopDownPhysics = TopDownPhysics;
})(Physics || (Physics = {}));
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/// <reference path="Common.ts" />
// TODO: This is not universal to all browsers!!!
var Sound;
(function (Sound) {
    var SoundClip = (function () {
        function SoundClip(path) {
            this.path = path;
            this.sound = new Audio(path);
            this.sound.preload = "false";
        }
        SoundClip.prototype.play = function () {
            //document.body.appendChild(this.sound);
            this.sound.play();
            //this.sound.play();
        };
        return SoundClip;
    })();
    Sound.SoundClip = SoundClip;
})(Sound || (Sound = {}));
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSIENSS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
/// <reference path="MonkeyPatch.ts" />
/// <reference path="Algebra.ts" />
/// <reference path="Drawing.ts" />
/// <reference path="Camera.ts" />
/// <reference path="Common.ts" />
/// <reference path="Physics.ts" />
/// <reference path="Sound.ts" />
var Core;
(function (Core) {
    Core.Keys = {
        "up": 38,
        "down": 40,
        "left": 37,
        "right": 39,
        "space": 32,
        "a": 65,
        "s": 83,
        "d": 68,
        "w": 87,
        "shift": 16,
        "b": 66,
        "c": 67,
        "e": 69,
        "f": 70,
        "g": 71,
        "h": 72,
        "i": 73,
        "j": 74,
        "k": 75,
        "l": 76,
        "m": 77,
        "n": 78,
        "o": 79,
        "p": 80,
        "q": 81,
        "r": 82,
        "t": 84,
        "u": 85,
        "v": 86,
        "x": 88,
        "y": 89,
        "z": 90
    };

    var Color = (function () {
        function Color(r, g, b, a) {
            this.r = r;
            this.g = g;
            this.b = b;
            this.a = a;
        }
        Color.prototype.toString = function () {
            var result = String(this.r.toFixed(0)) + ", " + String(this.g.toFixed(0)) + ", " + String(this.b.toFixed(0));
            if (this.a) {
                return "rgba(" + result + ", " + String(this.a) + ")";
            }
            return "rgb(" + result + ")";
        };
        return Color;
    })();
    Core.Color = Color;

    var Actor = (function () {
        function Actor() {
            // Initial position is 0
            this.x = 0;
            this.y = 0;
            // Initial velocity is 0
            this.dx = 0;
            this.dy = 0;
            // Initial acceleartion is 0;
            this.ax = 0;
            this.ay = 0;
            // List of animations for an Actor
            this.animations = {};
            // Current animation for an Actor
            this.currentAnimation = null;
        }
        // Add an animation to Actor's list
        Actor.prototype.addAnimation = function (key, animation) {
            this.animations[key] = animation;
            if (!this.currentAnimation) {
                this.currentAnimation = animation;
            }
        };

        Actor.prototype.setBox = function (box) {
            this.box = box;
        };

        Actor.prototype.getBox = function () {
            return this.box;
        };

        Actor.prototype.setPhysicsSystem = function (system) {
            this.physicsSystem = system;
        };

        Actor.prototype.getPhysicsSystem = function () {
            return this.physicsSystem;
        };

        Actor.prototype.setX = function (x) {
            this.x = x;
        };

        Actor.prototype.getX = function () {
            return this.x;
        };

        Actor.prototype.setY = function (y) {
            this.y = y;
        };

        Actor.prototype.getY = function () {
            return this.y;
        };

        Actor.prototype.setDx = function (dx) {
            this.dx = dx;
        };

        Actor.prototype.getDx = function () {
            return this.dx;
        };

        Actor.prototype.setDy = function (dy) {
            this.dy = dy;
        };

        Actor.prototype.getDy = function () {
            return this.dy;
        };

        Actor.prototype.setAx = function (ax) {
            this.ax = ax;
        };

        Actor.prototype.getAx = function () {
            return this.ax;
        };

        Actor.prototype.setAy = function (ay) {
            this.ay = ay;
        };

        Actor.prototype.getAy = function () {
            return this.ay;
        };

        Actor.prototype.adjustX = function (x) {
            this.x += x;
        };

        Actor.prototype.adjustY = function (y) {
            this.y += y;
        };

        Actor.prototype.getColor = function () {
            return this.color;
        };

        Actor.prototype.setColor = function (color) {
            this.color = color;
        };

        // Play animation in Actor's list
        Actor.prototype.playAnimation = function (key) {
            this.currentAnimation = this.animations[key];
        };

        Actor.prototype.update = function (engine, delta) {
            // Update placements based on linear algebra
            this.x += this.dx;
            this.y += this.dy;

            this.dx += this.ax;
            this.dy += this.ay;
        };
        Actor.prototype.draw = function (ctx, delta) {
            // override
        };
        return Actor;
    })();
    Core.Actor = Actor;

    var Player = (function (_super) {
        __extends(Player, _super);
        function Player(x, y, width, height) {
            _super.call(this);
            this.width = width;
            this.height = height;
            // bounding box
            //private box : Physics.Box;
            // List of key handlers for a player
            this.handlers = {};
            this.x = x;
            this.y = y;
            this.box = new Physics.Box(x, y, width, height);
        }
        Player.prototype.getBox = function () {
            return this.box;
        };

        Player.prototype.addKeyHandler = function (key, handler) {
            for (var i in key) {
                var k = key[i];
                this.handlers[k] = handler;
            }
        };

        Player.prototype.update = function (engine, delta) {
            // Key Input
            var keys = engine.getKeys();

            for (var key in this.handlers) {
                var pressedKey = engine.getKeyMap()[key];
                if (keys.indexOf(pressedKey) > -1) {
                    this.handlers[key](this);
                }
            }

            // Update placements based on linear algebra
            _super.prototype.update.call(this, engine, delta);

            this.box.setLeft(this.x);
            this.box.setTop(this.y);
        };

        Player.prototype.draw = function (ctx, delta) {
            if (this.currentAnimation) {
                this.currentAnimation.draw(ctx, this.x, this.y);
            } else {
                ctx.fillStyle = this.color ? this.color.toString() : (new Color(0, 0, 0)).toString();
                ctx.fillRect(this.box.x, this.box.y, this.box.width, this.box.height);
            }
        };
        return Player;
    })(Actor);
    Core.Player = Player;

    var Block = (function (_super) {
        __extends(Block, _super);
        function Block(x, y, width, height, color) {
            _super.call(this);
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.color = color;
            this.boundingBox = new Physics.Box(this.x, this.y, this.width, this.height);
        }
        Block.prototype.getBox = function () {
            return this.boundingBox;
        };

        Block.prototype.toString = function () {
            return "[x:" + this.boundingBox.x + ", y:" + this.boundingBox.y + ", w:" + this.boundingBox.width + ", h:" + this.boundingBox.height + "]";
        };

        Block.prototype.update = function (engine, delta) {
            // Update placements based on linear algebra
            this.x += this.dx;
            this.y += this.dy;

            this.boundingBox.x += this.dx;
            this.boundingBox.y += this.dy;

            this.dx += this.ax;
            this.dy += this.ay;
        };
        Block.prototype.draw = function (ctx, delta) {
            if (this.currentAnimation) {
                this.currentAnimation.draw(ctx, this.boundingBox.x, this.boundingBox.y);
            } else {
                ctx.fillStyle = this.color ? this.color.toString() : (new Color(0, 0, 0)).toString();
                ctx.fillRect(this.boundingBox.x, this.boundingBox.y, this.boundingBox.width, this.boundingBox.height);
            }
        };
        return Block;
    })(Actor);
    Core.Block = Block;

    var SimpleGame = (function () {
        function SimpleGame(width, height, fullscreen, backgroundColor) {
            this.width = width;
            this.height = height;
            this.fullscreen = fullscreen;
            this.backgroundColor = backgroundColor;
            this.actors = [];
            this.level = [];
            // default fps 30
            this.fps = 30;
            // debug stuff
            this.isDebugOn = false;
            this.debugColor = new Color(250, 0, 0);
            this.debugFontSize = 10;
            // key buffer
            this.keys = [];
            // key mappings
            this.keyMap = Core.Keys;
            this.reverseKeyMap = {};
            // internal canvase
            this.canv = document.createElement("canvas");
            // internal camera
            this.camera = null;
            for (var id in this.keyMap) {
                this.reverseKeyMap[this.keyMap[id]] = id;
            }
        }
        SimpleGame.prototype.setDebugFontSize = function (debugFontSize) {
            this.debugFontSize = debugFontSize;
        };

        SimpleGame.prototype.setDebug = function (isDebugOn) {
            this.isDebugOn = isDebugOn;
        };

        SimpleGame.prototype.setDebugColor = function (debugColor) {
            this.debugColor = debugColor;
        };

        SimpleGame.prototype.setFps = function (fps) {
            this.fps = fps;
        };

        SimpleGame.prototype.setHeight = function (height) {
            this.height = height;
        };

        SimpleGame.prototype.getHeight = function () {
            return this.height;
        };

        SimpleGame.prototype.setWidth = function (width) {
            this.width = width;
        };

        SimpleGame.prototype.getWidth = function () {
            return this.width;
        };

        SimpleGame.prototype.setFullscreen = function (fullscreen) {
            this.fullscreen = fullscreen;
        };

        SimpleGame.prototype.isFullscreen = function () {
            return this.fullscreen;
        };

        SimpleGame.prototype.setBackgroundColor = function (color) {
            this.backgroundColor = color;
        };

        SimpleGame.prototype.getBackgroundColor = function () {
            return this.backgroundColor;
        };

        SimpleGame.prototype.getKeys = function () {
            return this.keys;
        };

        SimpleGame.prototype.getKeyMap = function () {
            return this.keyMap;
        };

        SimpleGame.prototype.getActors = function () {
            return this.actors;
        };

        SimpleGame.prototype.getLevel = function () {
            return this.level;
        };

        SimpleGame.prototype.update = function (engine, delta) {
            for (var i = 0; i < this.actors.length; i++) {
                this.actors[i].update(engine, delta);
            }
            if (this.physicsSystem) {
                this.physicsSystem.update(delta);
            }
        };

        SimpleGame.prototype.addPhysics = function (physicsSystem) {
            this.physicsSystem = physicsSystem;
        };

        SimpleGame.prototype.addCamera = function (camera) {
            this.camera = camera;
        };

        SimpleGame.prototype.getCamera = function () {
            return this.camera;
        };

        SimpleGame.prototype.getGraphicsCtx = function () {
            return this.ctx;
        };

        SimpleGame.prototype.getCanvas = function () {
            return this.canv;
        };

        SimpleGame.prototype.draw = function (ctx, delta) {
            if (!this.backgroundColor) {
                this.backgroundColor = new Color(0, 0, 0);
            }

            // Draw Background color
            this.ctx.fillStyle = this.backgroundColor.toString();
            this.ctx.fillRect(0, 0, this.width, this.height);

            if (this.isDebugOn) {
                this.ctx.font = this.debugFontSize + "pt Consolas";
                this.ctx.fillStyle = this.debugColor.toString();
                for (var j = 0; j < this.keys.length; j++) {
                    this.ctx.fillText(this.keys[j] + " : " + (this.reverseKeyMap[this.keys[j]] ? this.reverseKeyMap[this.keys[j]] : "Not Mapped"), 10, 10 * j + 10);
                }

                var fps = 1.0 / (delta / 1000);
                this.ctx.fillText("FPS:" + fps.toFixed(2).toString(), 90, 10);
            }

            ctx.save();

            if (this.camera) {
                this.camera.applyTransform(this, delta);
            }

            for (var k = 0; k < this.level.length; k++) {
                this.level[k].draw(ctx, delta);
            }

            for (var i = 0; i < this.actors.length; i++) {
                this.actors[i].draw(ctx, delta);
            }
            ctx.restore();
        };

        SimpleGame.prototype.addActor = function (actor) {
            this.actors.push(actor);
        };

        SimpleGame.prototype.addBlock = function (block) {
            this.level.push(block);
        };

        SimpleGame.prototype.start = function () {
            var _this = this;
            // TODO: LoopTime needs to be updated in requestAnimationFrame
            // Calculate loop time based on fps value
            var loopTime = (1.0 / this.fps) * 1000;

            // Capture key events
            window.onkeydown = function (ev) {
                if (_this.keys.indexOf(ev.keyCode) < 0) {
                    _this.keys.push(ev.keyCode);
                }
            };
            window.onkeyup = function (ev) {
                var key = _this.keys.indexOf(ev.keyCode);
                _this.keys.splice(key, 1);
            };

            // Setup canvas drawing surface in DOM
            this.canv.width = this.width;
            this.canv.height = this.height;
            if (this.fullscreen) {
                document.body.style.margin = "0";
                this.canv.style.width = "100%";
                this.canv.style.height = "100%";
            }
            document.body.appendChild(this.canv);
            this.ctx = this.canv.getContext("2d");

            // this has been added to the html5 canvas spec, but not all browsers implement it including chrome.
            (this.ctx).webkitImageSmoothingEnabled = false;
            (this.ctx).mozImageSmoothingEnabled = false;
            (this.ctx).msImageSmoothingEnabled = false;
            (this.ctx).imageSmoothingEnabled = false;

            // Mainloop
            var lastTime = Date.now();
            var game = this;
            (function mainloop() {
                window.requestAnimationFrame(mainloop);

                // Get the time to calculate time-elapsed
                var now = Date.now();
                var elapsed = Math.floor((now - lastTime));

                game.update(game, elapsed);
                game.draw(game.ctx, elapsed);

                lastTime = now;
            })();
        };
        return SimpleGame;
    })();
    Core.SimpleGame = SimpleGame;
})(Core || (Core = {}));
