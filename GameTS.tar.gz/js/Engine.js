/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
var Algebra;
(function (Algebra) {
    var Util = (function () {
        function Util() { }
        Util.Equals = function Equals(x, y, delta) {
            return (((x - delta) <= y) && (y <= (x + delta)));
        };
        return Util;
    })();
    Algebra.Util = Util;    
    var Point = (function () {
        function Point(x, y) {
            this.x = x;
            this.y = y;
        }
        Point.prototype.minus = function (p) {
            return new Vector(this.x - p.x, this.y - p.y);
        };
        Point.prototype.plus = function (v) {
            this.x += v.x;
            this.y += v.y;
            return this;
        };
        return Point;
    })();
    Algebra.Point = Point;    
    var Vector = (function () {
        function Vector(x, y) {
            this.x = x;
            this.y = y;
        }
        Vector.prototype.dot = function (v) {
            return this.x * v.x + this.y * v.y;
        };
        Vector.prototype.cross = // 2d cross product returns a scalar
        function (v) {
            return this.x * v.y - this.y * v.x;
        };
        return Vector;
    })();
    Algebra.Vector = Vector;    
})(Algebra || (Algebra = {}));
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
var Drawing;
(function (Drawing) {
    var SpriteSheet = (function () {
        function SpriteSheet(path, columns, rows, spWidth, spHeight) {
            this.path = path;
            this.sprites = {
            };
            this.internalImage = new Image();
            this.internalImage.src = path;
            for(var i = 0; i < rows; i++) {
                this.sprites[i] = [];
                for(var j = 0; j < columns; j++) {
                    this.sprites[i].push(new Sprite(this.internalImage, j * spWidth, i * spHeight, spWidth, spHeight));
                }
            }
        }
        SpriteSheet.prototype.getAnimationForRow = function (rowIndex, start, count, speed) {
            return new Animation(this.sprites[rowIndex].slice(start, start + count), speed);
        };
        return SpriteSheet;
    })();
    Drawing.SpriteSheet = SpriteSheet;    
    var Sprite = (function () {
        function Sprite(image, sx, sy, swidth, sheight) {
            this.sx = sx;
            this.sy = sy;
            this.swidth = swidth;
            this.sheight = sheight;
            this.scale = 1.0;
            this.rotation = 0.0;
            this.internalImage = image;
        }
        Sprite.prototype.setRotation = function (radians) {
            this.rotation = radians;
        };
        Sprite.prototype.setScale = function (scale) {
            this.scale = scale;
        };
        Sprite.prototype.draw = function (ctx, x, y) {
            ctx.drawImage(this.internalImage, this.sx, this.sy, this.swidth, this.sheight, x, y, this.swidth * this.scale, this.sheight * this.scale);
        };
        return Sprite;
    })();
    Drawing.Sprite = Sprite;    
    var Animation = (function () {
        function Animation(images, speed) {
            this.currIndex = 0;
            this.oldTime = new Date().getTime();
            this.rotation = 0.0;
            this.scale = 1.0;
            this.sprites = images;
            this.speed = speed;
            this.maxIndex = images.length;
        }
        Animation.prototype.setRotation = function (radians) {
            this.rotation = radians;
            for(var i in this.sprites) {
                this.sprites[i].setRotation(radians);
            }
        };
        Animation.prototype.setScale = function (scale) {
            this.scale = scale;
            for(var i in this.sprites) {
                this.sprites[i].setScale(scale);
            }
        };
        Animation.prototype.tick = function () {
            var time = new Date().getTime();
            if((time - this.oldTime) / 1000 > this.speed) {
                this.currIndex = (this.currIndex + 1) % this.maxIndex;
                this.oldTime = time;
            }
        };
        Animation.prototype.draw = function (ctx, x, y) {
            this.tick();
            this.sprites[this.currIndex].draw(ctx, x, y);
        };
        return Animation;
    })();
    Drawing.Animation = Animation;    
})(Drawing || (Drawing = {}));
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
var Camera;
(function (Camera) {
    var SideCamera = (function () {
        function SideCamera() {
        }
        SideCamera.prototype.setActorToFollow = function (actor) {
            this.follow = actor;
        };
        SideCamera.prototype.applyTransform = function (ctx, delta) {
            ctx.translate(-this.follow.box.x + 400, 0);
        };
        return SideCamera;
    })();
    Camera.SideCamera = SideCamera;    
})(Camera || (Camera = {}));
var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
/**
Copyright (c) 2013 Erik Onarheim
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software
must display the following acknowledgement:
This product includes software developed by the GameTS Team.
4. Neither the name of the creator nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE GAMETS TEAM ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE GAMETS TEAM BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/// <reference path="Algebra.ts" />
/// <reference path="Drawing.ts" />
/// <reference path="Camera.ts" />
var Core;
(function (Core) {
    var Keys = {
        "up": 38,
        "down": 40,
        "left": 37,
        "right": 39,
        "space": 32,
        "a": 65,
        "s": 83,
        "d": 68,
        "w": 87,
        "shift": 16
    };
    var Sound = (function () {
        function Sound(path) {
            this.path = path;
            this.sound = new Audio(path);
            this.sound.preload = "false";
        }
        Sound.prototype.play = function () {
            //document.body.appendChild(this.sound);
            this.sound.play();
            //this.sound.play();
                    };
        return Sound;
    })();
    Core.Sound = Sound;    
    // Abstract class, must override update and draw
    var Actor = (function () {
        function Actor() {
            // Initial velocity is 0
            this.dx = 0;
            this.dy = 0;
            // Initial acceleartion is 0;
            this.ax = 0;
            this.ay = 0;
            // List of animations for an Actor
            this.animations = {
            };
            // Current animation for an Actor
            this.currentAnimation = null;
        }
        Actor.prototype.addAnimation = // Add an animation to Actor's list
        function (key, animation) {
            this.animations[key] = animation;
            if(!this.currentAnimation) {
                this.currentAnimation = animation;
            }
        };
        Actor.prototype.playAnimation = // Play animation in Actor's list
        function (key) {
            this.currentAnimation = this.animations[key];
        };
        Actor.prototype.update = function (engine, delta) {
            // override
                    };
        Actor.prototype.draw = function (ctx, delta) {
            // override
                    };
        return Actor;
    })();
    Core.Actor = Actor;    
    var Color = (function () {
        function Color(r, g, b) {
            this.r = r;
            this.g = g;
            this.b = b;
        }
        Color.prototype.toString = function () {
            return "rgb(" + String(this.r.toFixed(0)) + ", " + String(this.g.toFixed(0)) + ", " + String(this.b.toFixed(0)) + ")";
        };
        return Color;
    })();
    Core.Color = Color;    
    // Side scroller physics implementation w/o inertia
    var SideScrollerPhysics = (function () {
        function SideScrollerPhysics(actor, engine) {
            this.actor = actor;
            this.engine = engine;
            this.gravity = 4;
            this.onGround = false;
        }
        SideScrollerPhysics.prototype.isGround = function () {
            return this.onGround;
        };
        SideScrollerPhysics.prototype.setGround = function (onGround) {
            this.onGround = onGround;
        };
        SideScrollerPhysics.prototype.setGravity = function (gravity) {
            this.gravity = gravity;
        };
        SideScrollerPhysics.prototype.update = function (delta) {
            this.actor.ay = this.gravity;
            this.onGround = false;
            // Pseudo-Friction
            this.actor.dx = 0;
            // Test Collision
            for(var i = 0; i < this.engine.level.length; i++) {
                var levelBox = this.engine.level[i].boundingBox;
                if(this.actor.box.collides(levelBox)) {
                    var overlap = this.actor.box.getOverlap(levelBox);
                    if(Math.abs(overlap.y) < Math.abs(overlap.x)) {
                        this.actor.box.y += overlap.y;
                        this.actor.dy = 0;
                        /// TODO: This isn't quite right since if we collide on the y we are considered "on the ground"
                        this.onGround = true;
                    } else {
                        this.actor.box.x += overlap.x;
                        this.actor.dx = 0;
                    }
                }
            }
        };
        return SideScrollerPhysics;
    })();
    Core.SideScrollerPhysics = SideScrollerPhysics;    
    // Side scroller physics implementation w inertia
    var SideScrollerInertiaPhysics = (function () {
        function SideScrollerInertiaPhysics() {
        }
        SideScrollerInertiaPhysics.prototype.isGround = function () {
            return false;
        };
        SideScrollerInertiaPhysics.prototype.setGround = function (onGround) {
        };
        SideScrollerInertiaPhysics.prototype.update = function (delta) {
        };
        return SideScrollerInertiaPhysics;
    })();
    Core.SideScrollerInertiaPhysics = SideScrollerInertiaPhysics;    
    // Top down game physics implementation
    var TopDownPhysics = (function () {
        function TopDownPhysics(actor, engine) {
            this.actor = actor;
            this.engine = engine;
            this.friction = 0;
        }
        TopDownPhysics.prototype.setFriction = function (friction) {
            this.friction = friction;
        };
        TopDownPhysics.prototype.isGround = function () {
            return false;
        };
        TopDownPhysics.prototype.setGround = function (onGround) {
        };
        TopDownPhysics.prototype.update = function (delta) {
            // Pseudo-Friction
            if(this.actor.dx != 0) {
                if(Math.abs(this.actor.dx) <= this.friction) {
                    this.actor.dx = 0;
                } else {
                    this.actor.dx = this.actor.dx + (this.actor.dx > 0 ? -1 : 1) * this.friction;
                }
            }
            if(this.actor.dy != 0) {
                if(Math.abs(this.actor.dy) <= this.friction) {
                    this.actor.dy = 0;
                } else {
                    this.actor.dy = this.actor.dy + (this.actor.dy > 0 ? -1 : 1) * this.friction;
                }
            }
            //this.actor.dx = 0;
            //this.actor.dy = 0;
            // Test Collision
            for(var i = 0; i < this.engine.level.length; i++) {
                var levelBox = this.engine.level[i].boundingBox;
                if(this.actor.box.collides(levelBox)) {
                    var overlap = this.actor.box.getOverlap(levelBox);
                    if(Math.abs(overlap.y) < Math.abs(overlap.x)) {
                        this.actor.box.y += overlap.y;
                        this.actor.dy = 0;
                    } else {
                        this.actor.box.x += overlap.x;
                        this.actor.dx = 0;
                    }
                }
            }
        };
        return TopDownPhysics;
    })();
    Core.TopDownPhysics = TopDownPhysics;    
    var Player = (function (_super) {
        __extends(Player, _super);
        function Player(x, y, width, height) {
                _super.call(this);
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            // internal physics system
            this.system = null;
            // List of key handlers for a player
            this.handlers = {
            };
            this.box = new Box(x, y, width, height);
        }
        Player.prototype.setPhysicsSystem = function (system) {
            this.system = system;
        };
        Player.prototype.getPhysicsSystem = function () {
            return this.system;
        };
        Player.prototype.addKeyHandler = /*
        addKeyHandler(key:string, handler: (player:Player) => void){
        this.handlers[key] = handler;
        }*/
        function (key, handler) {
            for(var i in key) {
                var k = key[i];
                this.handlers[k] = handler;
            }
        };
        Player.prototype.update = function (engine, delta) {
            // Key Input
            var keys = engine.keys;
            for(var key in this.handlers) {
                var pressedKey = engine.keyMap[key];
                if(keys.indexOf(pressedKey) > -1) {
                    this.handlers[key](this);
                }
            }
            // Update placements based on linear algebra
            this.box.x += this.dx;
            this.box.y += this.dy;
            this.dx += this.ax;
            this.dy += this.ay;
            // Update placements based on physics system if one exists
            if(this.system) {
                this.system.update(delta);
            }
        };
        Player.prototype.draw = function (ctx, delta) {
            if(this.currentAnimation) {
                this.currentAnimation.draw(ctx, this.box.x, this.box.y);
            } else {
                ctx.fillStyle = "rgb(" + String(245) + ", " + String(110) + ", " + String(148) + ")";
                ctx.fillRect(this.box.x, this.box.y, this.box.width, this.box.height);
            }
        };
        return Player;
    })(Actor);
    Core.Player = Player;    
    var Block = (function (_super) {
        __extends(Block, _super);
        function Block(x, y, width, height, color) {
                _super.call(this);
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.color = color;
            this.boundingBox = new Box(this.x, this.y, this.width, this.height);
        }
        Block.prototype.toString = function () {
            return "[x:" + this.boundingBox.x + ", y:" + this.boundingBox.y + ", w:" + this.boundingBox.width + ", h:" + this.boundingBox.height + "]";
        };
        Block.prototype.update = function (engine, delta) {
        };
        Block.prototype.draw = function (ctx, delta) {
            if(this.currentAnimation) {
                this.currentAnimation.draw(ctx, this.boundingBox.x, this.boundingBox.y);
            } else {
                ctx.fillStyle = this.color.toString();
                ctx.fillRect(this.boundingBox.x, this.boundingBox.y, this.boundingBox.width, this.boundingBox.height);
            }
        };
        return Block;
    })(Actor);
    Core.Block = Block;    
    var Overlap = (function () {
        function Overlap(x, y) {
            this.x = x;
            this.y = y;
        }
        return Overlap;
    })();
    Core.Overlap = Overlap;    
    var Box = (function () {
        function Box(x, y, width, height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
        Box.prototype.getLeft = function () {
            return this.x;
        };
        Box.prototype.setLeft = function (left) {
            this.x = left;
        };
        Box.prototype.getRight = function () {
            return this.x + this.width;
        };
        Box.prototype.setRight = function (right) {
            this.width = right - this.x;
        };
        Box.prototype.getTop = function () {
            return this.y;
        };
        Box.prototype.setTop = function (top) {
            this.y = top;
        };
        Box.prototype.getBottom = function () {
            return this.y + this.height;
        };
        Box.prototype.setBottom = function (bottom) {
            this.height = bottom - this.y;
        };
        Box.prototype.getOverlap = function (box) {
            var xover = 0;
            var yover = 0;
            if(this.collides(box)) {
                if(this.getLeft() < box.getRight()) {
                    xover = box.getRight() - this.getLeft();
                }
                if(box.getLeft() < this.getRight()) {
                    var tmp = box.getLeft() - this.getRight();
                    if(Math.abs(xover) > Math.abs(tmp)) {
                        xover = tmp;
                    }
                }
                if(this.getBottom() > box.getTop()) {
                    yover = box.getTop() - this.getBottom();
                }
                if(box.getBottom() > this.getTop()) {
                    var tmp = box.getBottom() - this.getTop();
                    if(Math.abs(yover) > Math.abs(tmp)) {
                        yover = tmp;
                    }
                }
            }
            return new Overlap(xover, yover);
        };
        Box.prototype.collides = function (box) {
            var w = 0.5 * (this.width + box.width);
            var h = 0.5 * (this.height + box.height);
            var dx = (this.x + this.width / 2.0) - (box.x + box.width / 2.0);
            var dy = (this.y + this.height / 2.0) - (box.y + box.height / 2.0);
            if(Math.abs(dx) < w && Math.abs(dy) < h) {
                return true;
            }
        };
        return Box;
    })();
    Core.Box = Box;    
    var Game = (function () {
        function Game() {
        }
        return Game;
    })();
    Core.Game = Game;    
    var TopDownGame = (function (_super) {
        __extends(TopDownGame, _super);
        function TopDownGame() {
                _super.call(this);
        }
        return TopDownGame;
    })(Game);
    Core.TopDownGame = TopDownGame;    
    var SimpleGame = (function (_super) {
        __extends(SimpleGame, _super);
        function SimpleGame(width, height, fullscreen, backgroundColor) {
                _super.call(this);
            this.width = width;
            this.height = height;
            this.fullscreen = fullscreen;
            this.backgroundColor = backgroundColor;
            this.debugFontSize = 50;
            this.actors = [];
            this.level = [];
            // key buffer
            this.keys = [];
            // key mappings
            this.keyMap = Keys;
            // internal canvase
            this.canv = document.createElement("canvas");
            // internal camera
            this.camera = null;
            this.actors = [];
        }
        SimpleGame.prototype.update = function (engine, delta) {
            for(var i = 0; i < this.actors.length; i++) {
                this.actors[i].update(engine, delta);
            }
        };
        SimpleGame.prototype.addCamera = function (camera) {
            this.camera = camera;
        };
        SimpleGame.prototype.draw = function (ctx, delta) {
            if(!this.backgroundColor) {
                this.backgroundColor = new Color(0, 0, 0);
            }
            // Draw Background color
            this.ctx.fillStyle = this.backgroundColor.toString();
            this.ctx.fillRect(0, 0, this.width, this.height);
            // Draw debug information
            this.ctx.fillStyle = new Color(250, 0, 0).toString();
            for(var j = 0; j < this.keys.length; j++) {
                this.ctx.fillText(this.keys[j], 10, 10 * j + 10);
            }
            ctx.save();
            if(this.camera) {
                this.camera.applyTransform(ctx, delta);
            }
            // Draw level
            for(var k = 0; k < this.level.length; k++) {
                this.level[k].draw(ctx, delta);
            }
            // Draw actors
            for(var i = 0; i < this.actors.length; i++) {
                this.actors[i].draw(ctx, delta);
            }
            ctx.restore();
        };
        SimpleGame.prototype.addActor = function (actor) {
            this.actors.push(actor);
        };
        SimpleGame.prototype.addBlock = function (block) {
            this.level.push(block);
        };
        SimpleGame.prototype.start = function () {
            var _this = this;
            // Mainloop
            window.setInterval(function () {
                _this.update(_this, 20);
                _this.draw(_this.ctx, 20);
            }, 20);
            // Capture key events
            window.onkeydown = function (ev) {
                if(_this.keys.indexOf(ev.keyCode) < 0) {
                    _this.keys.push(ev.keyCode);
                }
            };
            window.onkeyup = function (ev) {
                var key = _this.keys.indexOf(ev.keyCode);
                _this.keys.splice(key, 1);
            };
            // Setup canvas drawing surface in DOM
            this.canv.width = this.width;
            this.canv.height = this.height;
            if(this.fullscreen) {
                document.body.style.margin = "0";
                this.canv.style.width = "100%";
                this.canv.style.height = "100%";
            }
            document.body.appendChild(this.canv);
            this.ctx = this.canv.getContext("2d");
        };
        return SimpleGame;
    })(Game);
    Core.SimpleGame = SimpleGame;    
})(Core || (Core = {}));
